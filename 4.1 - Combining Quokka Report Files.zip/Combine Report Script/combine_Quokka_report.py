# -*- coding: utf-8 -*-
"""
Created on Mon Mar  7 11:56:34 2022

@author: z3486032
"""

import pathlib

# Set up a frozen class to prevent new attribute from being added after __init__
class FrozenClass(object):
    __isfrozen = False
    def __setattr__(self, key, value):
        if self.__isfrozen and not hasattr(self, key):
            raise TypeError( "Class {} is frozen. Cannot set {} = {}"
                            .format(type(self).__name__, key, value))
        object.__setattr__(self, key, value)

    def _freeze(self):
        self.__isfrozen = True
    pass


# Class for combining Quokka report
class combine_Quokka_report(FrozenClass):
    def __init__(self):
        # Set up working directory
        self.report_dir = pathlib.Path().resolve().parent /  'Quokka Report Files'
        
        # Set up working variables
        self.emp_20m = '0195839' # Direct/Empty Beam Transmission at 20m
        self.emp_lens = '0195838' # Direct/Empty Beam Transmission at lens
        self.header = '<?xml version="1.0" encoding="UTF-8"?>\n<report>\n'
        self.footer = '</report>'
        
        # Prevent new attributes from being added
        self._freeze()
    
    # Combining report files
    def combine(self):
        # Get list of report files
        file_list = list(self.report_dir.iterdir())
        
        # Empty list containing information of each SANS config
        result_lens = []
        result_20m = []
        result_8m = []
        result_1m = []
        
        # Extracting information containing within each report
        for file_path in file_list:
            print(file_path.parts[-1])
            
            # Read individual report content
            with open(self.report_dir / file_path) as file:
                data = file.readlines()
                
            # Get all the starting and ending rows for each SANS configuration
            # contained within each report file
            config_start_loc = [i for i in range(len(data))
                                if '<config name=' in data[i]]
            config_end_loc = [i for i in range(len(data))
                                if '</config>' in data[i]]
            
            # Assign the appropriate starting and ending row for each config
            loc_1m_idx = [i for i in range(len(config_start_loc))
                          if '=1.3m_' in data[config_start_loc[i]]
                          or '=1p3m_' in data[config_start_loc[i]]][0]
            loc_8m_idx = [i for i in range(len(config_start_loc))
                          if '=8m_' in data[config_start_loc[i]]][0]
            loc_20m_idx = [i for i in range(len(config_start_loc))
                           if '=20m_central' in data[config_start_loc[i]]][0]
            loc_lens_idx = [i for i in range(len(config_start_loc))
                            if 'lens' in data[config_start_loc[i]]
                            or 'Lens' in data[config_start_loc[i]]][0]

            # Extract data and assign it to the appropriate variable using
            # the corresponding starting and ending rows obtained previously
            config_1m = data[config_start_loc[loc_1m_idx]:
                             config_end_loc[loc_1m_idx]+1]
            config_8m = data[config_start_loc[loc_8m_idx]:
                             config_end_loc[loc_8m_idx]+1]
            config_20m = data[config_start_loc[loc_20m_idx]:
                              config_end_loc[loc_20m_idx]+1]
            config_lens = data[config_start_loc[loc_lens_idx]:
                               config_end_loc[loc_lens_idx]+1]
            
            # Assign transmission information from the 20m config to the empty
            # info of the 1.34m and 8m configs  
            config_1m[1:3] = config_20m[1:3]
            config_8m[1:3] = config_20m[1:3]
            
            # Assign empty beam to the information of each configuration
            config_1m[-2] = ('    <emptyBeamTransmissionRunId>' 
                             + self.emp_20m + '</emptyBeamTransmissionRunId>\n')
            config_8m[-2] = ('    <emptyBeamTransmissionRunId>' 
                             + self.emp_20m + '</emptyBeamTransmissionRunId>\n')
            config_20m[-2] = ('    <emptyBeamTransmissionRunId>' 
                             + self.emp_20m + '</emptyBeamTransmissionRunId>\n')
            config_lens[-2] = ('    <emptyBeamTransmissionRunId>' 
                               + self.emp_lens + '</emptyBeamTransmissionRunId>\n')

            # Appending the info of each config to their corresponding variable
            result_lens += config_lens
            result_20m += config_20m
            result_8m += config_8m
            result_1m += config_1m
            
        # Combine and write result into ASCII file
        result = ([self.header] + 
                  result_lens + result_20m + result_8m + result_1m + 
                  [self.footer])
        with open('Combined_Quokka_Report.xml', 'w') as file:
            [file.write(line) for line in result]
            
def main():
    aaa = combine_Quokka_report()
    aaa.combine()

if __name__ == '__main__':
    main()