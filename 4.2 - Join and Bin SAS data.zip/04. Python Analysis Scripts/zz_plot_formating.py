# -*- coding: utf-8 -*-
"""
Created on Fri Oct  8 17:14:49 2021

@author: nhuha
"""



''' Common plot command:

ax.plot(QQ_thin2, ar_thin2, marker = marker_style[i][0], 
        linestyle = '', color = marker_style[i][1], 
        markersize = marker_style[i][2],
        label = plot_label[i], fillstyle = 'none', linewidth = 1)


ax.errorbar(QQ_amb, Fa_amb, yerr = err_amb, marker = 's', 
            markersize = 4*pf.scale, linestyle = '', 
            color = 'k', fillstyle = 'none', 
            elinewidth=pf.marker_scale*2, capsize=pf.scale*2)

ax.fill_between(QQ_smooth, err_upper_smooth, err_lower_smooth,
                color = marker_style[i][1], alpha = 0.2)

ax.text(self.fr_text_pos, fr_text_pos, 'f(r)', 
        fontsize = self.value_label_font_size, weight = 'bold',
        ha = 'right', va = 'top')


   
    
'''

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.ticker as ticker

import numpy as np


scale = 1#1.5 #1.4 #0.55
marker_scale = 1 #1 2

# Say, "the default sans-serif font is COMIC SANS"
matplotlib.rcParams['font.serif'] = 'Times New Roman'
# Then, "ALWAYS use sans-serif fonts"
matplotlib.rcParams['font.family'] = 'serif'

matplotlib.rcParams['mathtext.fontset'] = 'custom'
matplotlib.rcParams['mathtext.rm'] = 'Times New Roman'
matplotlib.rcParams['mathtext.it'] = 'Times New Roman:italic'
matplotlib.rcParams['mathtext.bf'] = 'Times New Roman:bold'

matplotlib.rc('image', cmap='turbo')

scat_vec = 'SCATTERING VECTOR Q (\u212B' + r'$\mathbf{^{-1}}$)'
scat_int = r'SCATTERING INTENSITY $\mathbf{(cm^{-1})}$'
CD4_SLD = 'BULK PHASE $\mathbf{CD_{4}}$ SLD $\mathbf{(10^{10}cm^{-2})}$'

plt.rc('lines', markeredgewidth = 0.9*scale)
plt.rc('lines', linewidth = 0.9*scale)
plt.rc('lines', markersize = 4*scale)

plt.rc('axes', labelweight = 'semibold')

plt.ion()

value_label_font_size = 10*scale
axis_label_font_size = 13*scale

# For setting up new plot
def new_plot(plot_num = 1, multiprocess = False):
    
    if multiprocess:
        fig = plt.figure()
    else:
        fig = plt.figure(plot_num)
        
    fig.clf()
    ax = fig.add_subplot(111)
    
    return fig, ax

def legend_spacing(scale_val, tight = False):
    if scale_val == 1 and not tight:
        return 0.5
    else:
        return 0.1
    
def border_padding(scale_val, tight = False):
    if scale_val == 1 and not tight:
        return 0.4
    else:
        return 0.4


# Define a set of markers for plotting data
def get_marker_list_short():
    return ['pb', 'og', 'sr', '^c', 'Hm', '*y']

def get_marker_list_long():
    return [['s', '#1f77b4', 3*marker_scale],
            ['D', '#aec7e8', 3*marker_scale],
            ['o', '#ff7f0e', 3.5*marker_scale],
            ['>', '#e377c2', 3*marker_scale],
            ['^', '#2ca02c', 4*marker_scale],
            ['v', '#9467bd', 3*marker_scale],
            ['<', '#c5b0d5', 3*marker_scale],
            ['1', '#8c564b', 4*marker_scale],
            ['2', '#c49c94', 4*marker_scale],
            ['3', '#e31a1c', 5*marker_scale],
            ['4', '#8c564b', 5*marker_scale],
            ['8', '#7f7f7f', 3.5*marker_scale],
            ['p', '#17becf', 4*marker_scale],
            ['*', '#a55194', 5*marker_scale],
            ['h', '#393b79', 3.5*marker_scale],
            ['x', '#ffbb78', 3*marker_scale],
            ['+', '#111111', 5*marker_scale]]


def legend_title(ax, title, location = 1, separate = False, has_frame = True):
    if ax.get_legend_handles_labels()[0] != [] and not separate:
        ax.get_legend().set_title(title)
        plt.setp(ax.get_legend().get_title(), multialignment='center') 
    else:
        anchored_text = matplotlib.offsetbox.AnchoredText(title, loc=location, 
                                                          prop=dict(ha='center',
                                                                    size = value_label_font_size))
        if has_frame:
            anchored_text.patch.set(linewidth = 0.8, alpha = 1,
                                    boxstyle = 'round,pad=0.,rounding_size=0.2')
        else:
            anchored_text.patch.set(linewidth = 0, alpha = 0)
        ax.add_artist(anchored_text)
    # else:
    #     ax.legend(title= title, facecolor = 'w', loc = location, framealpha = 1,
    #               title_fontsize = value_label_font_size, fontsize = 0, borderpad = 5*scale,
    #               labelspacing = legend_spacing(scale), handletextpad = 1e-5*scale,
    #               columnspacing = 0.01*scale)
    #     ax.get_legend().get_frame().set_edgecolor('k')
    #     ax.get_legend().get_frame().set_linewidth(0.75*scale)


def sci_num_x(num, dec_pts = 2):
    base = int(np.log10(num))
    val = num/10**base
    return (r'${:.' + str(dec_pts) + r'f} \times 10^{{{:.0f}}}$').format(val, base)

def sci_num_dot(num, dec_pts = 2):
    base = int(np.log10(num))
    val = num/10**base
    return (r'${:.' + str(dec_pts) + r'f} \cdot 10^{{{:.0f}}}$').format(val, base)



# Set up figure for plotting SAS data
def set_SAS_plot(fig, ax, is_fractal = True, legend_loc = 0,
                 set_fig_size = True, tight_legend = False):
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel(scat_vec, labelpad = -1.5*scale)
    ax.set_ylabel(scat_int, labelpad = -0.5*scale)
    ax.set_xlim([1e-5, 8e-1])
    ax.set_ylim([1e-4, 1e12])
    
    if is_fractal:
        format_plot(fig, ax, inv_x = True, legend_pos= legend_loc,
                    is_fractal= is_fractal, set_fig_size= set_fig_size,
                    xtick_pad = 4*scale, tight_legend = tight_legend)
    else:
        format_plot(fig, ax, inv_x = True, set_fig_size= set_fig_size,
                    xtick_pad = 4*scale)


def set_SAS_hi_Q_plot(fig, ax, is_fractal = False, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel(scat_vec, labelpad = -1.5*scale)
    ax.set_ylabel(scat_int, labelpad = -0.5*scale)
    ax.set_xlim([1e-2, 1.8])
    ax.set_ylim([2e-2, 1.4e3])
    # ax.set_xlim([3e-4, 8e-1])
    # ax.set_ylim([1e-3, 1e7])
    
    if is_fractal:
        format_plot(fig, ax, inv_x = True, 
                    is_fractal= is_fractal, set_fig_size= set_fig_size)
    else:
        format_plot(fig, ax, inv_x = True, set_fig_size= set_fig_size)


def set_SAS_colormap_v_event(fig, ax, cp, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_xlabel(scat_vec, labelpad = 0*scale)
    ax.set_ylabel("EXPERIMENTAL CONDITIONS", labelpad = -0.5*scale)
    yticks = ax.get_yticks()
    
    format_plot(fig, ax, set_fig_size = set_fig_size)
    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 17*scale,
                        cbar_label = scat_int)


def set_fr_SSA_plot(fig, ax, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('PORE RADIUS r & PROBE RADIUS R (nm)', labelpad = 0.5*scale,
                  ha = 'right', x = 1.03)
    ax.set_ylabel(r'f(r) & SSA(R) $\mathbf{(cm^{2}/cm^{3})}$', labelpad = -0.5*scale)
    # ax.set_xlim([1    , 5e5])
    # ax.set_ylim([1e-20, 1e12])
    # ax.set_xlim([1    , 1e3])
    # ax.set_ylim([1e-8, 1e9])
    ax.set_xlim([0.3 , 3e4])
    ax.set_ylim([1e-20, 1e12])
    # ax.set_ylim([1e-18, 1e9])
    # ax.set_xlim([1    , 1e4])
    # ax.set_ylim([1e-12, 1e12])

    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad=3*scale)
    
def set_SSA_rr_plot(fig, ax, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('PROBE RADIUS (\u212B)', labelpad = 0*scale)
    ax.set_ylabel(r'SPECIFIC SURFACE AREA $\mathbf{(cm^{2}/cm^{3})}$', 
                  labelpad = -0.5*scale)
    ax.set_xlim([1    , 1e5])
    ax.set_ylim([1e0, 1e8])
    
    format_plot(fig, ax, set_fig_size= set_fig_size)


def set_dV_on_dr_plot(fig, ax, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('PORE RADIUS r (nm)', labelpad = 0*scale)
    ax.set_ylabel(r'PORE VOLUME DISTRIBUTION $\mathbf{(cm^{3}/g}$' + '\u212B)', 
                  labelpad = 1*scale, va = 'bottom')
    ax.set_xlim([.1   , 1e3])
    ax.set_ylim([1e-8, 5e-2])
    ax.yaxis.set_label_coords(-0.09,0.445)

    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad=3*scale)
    plt.tight_layout(rect=(0,0,1,1.04))

    

def set_fr_plot_combined(fig, ax, cp, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_xlabel('PORE RADIUS r (\u212B)', labelpad = 0*scale)
    ax.set_ylabel("EXPERIMENTAL CONDITIONS", labelpad = -0.5*scale)
    yticks = ax.get_yticks()
    
    format_plot(fig, ax, set_fig_size = set_fig_size)
    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 17*scale,
                        cbar_label = r'f(r) $\mathbf{(cm^{2}/cm^{3})}$')

def set_SSA_plot_combined(fig, ax, cp, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_xlabel('PROBE RADIUS R (\u212B)', labelpad = 0*scale)
    ax.set_ylabel("EXPERIMENTAL CONDITIONS", labelpad = -0.5*scale)
    yticks = ax.get_yticks()
    
    format_plot(fig, ax, set_fig_size = set_fig_size)
    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 18*scale,
                        cbar_label = r'SSA(R) $\mathbf{(cm^{2}/cm^{3})}$')

def set_dV_on_dr_plot_combined(fig, ax, cp, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_xlabel('PROBE RADIUS (\u212B)', labelpad = 0*scale)
    ax.set_ylabel("EXPERIMENTAL CONDITIONS", labelpad = -0.5*scale)
    yticks = ax.get_yticks()
    
    format_plot(fig, ax, set_fig_size = set_fig_size)
    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 18*scale,
                        cbar_label = ('PORE VOLUME DISTRIBUTION ' + 
                                      '$\mathbf{(cm^{3}/g}$' + '\u212B)'))

def set_SLD_map(fig, ax, cp, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_xlabel('PORE RADIUS r (\u212B)', labelpad = 0*scale)
    ax.set_ylabel('CD\u2084 PRESSURE (BAR)', labelpad = -0.5*scale)
    yticks = ax.get_yticks()
    
    format_plot(fig, ax, set_fig_size = set_fig_size)
    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 17*scale,
                        cbar_label = r'NORMALISED CONTRAST $\mathbf{(cm^{-2})}$')
    
def set_sqrtIQ_v_SLD_plot_combined(fig, ax, cp, set_fig_size = True):
    
    ax.set_xscale('log')
    ax.set_xlabel('SCATTERING VECTOR Q (\u212B' + r'$\mathbf{^{-1}}$)',
                  labelpad = 0*scale)
    ax.set_ylabel(r"CD\u2084 SLD (10\u00B9\u2070 cm\u00B2)", labelpad = -0.5*scale)
    yticks = ax.get_yticks()

    format_plot(fig, ax, set_fig_size = False, inv_x = True, is_fractal = True) 

    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 19*scale,
                        cbar_label = 'SQUAREROOT OF THE\nSCATTERING INTENSITY')

def set_SANS_v_P_plot_combined(fig, ax, cp, set_fig_size = True):
    
    ax.set_xscale('log')
    ax.set_xlabel('SCATTERING VECTOR Q (\u212B' + r'$\mathbf{^{-1}}$)',
                  labelpad = -5*scale)
    ax.set_ylabel("CD\u2084 PRESSURE (bar)", labelpad = -0.5*scale)
    yticks = ax.get_yticks()

    format_plot(fig, ax, set_fig_size = set_fig_size, inv_x = True, 
                is_fractal = True, xtick_pad= 3) 

    format_contour_plot(fig, ax, cp, yticks, cbar_label_pad = 14*scale,
                        cbar_label = scat_int)
    
def set_F_a_r_plot(fig, ax, set_fig_size = True):
    ax.set_xscale('log')
    ax.set_xlabel(scat_vec, labelpad = -3*scale)
    ax.set_ylabel('ACCESSIBLE PORE FRACTION', labelpad = -0.5*scale)
    # ax.set_xlim([1e-5, 8e-1])
    # ax.set_ylim([-0.8, 1.2])
    # ax.set_xlim([1e-5, 8e-1])
    # ax.set_ylim([-0.5, 1])
    ax.set_xlim([3e-4, 8e-1])
    ax.set_ylim([-0.8, 1.2])
    
    format_plot(fig, ax, inv_x = True, is_fractal= True,
                set_fig_size= set_fig_size, ytick_num = 6)

def set_anisotropy_plot(fig, ax):
    ax.set_xscale('log')
    ax.set_xlabel(scat_vec)
    ax.set_ylabel('INTENSITY RATIO')
    ax.set_xlim([3e-4, 8e-1])
    ax.set_ylim([0, 1.2])
    
    format_plot(fig, ax, inv_x = True, is_fractal= True, 
                xtick_pad = 13, tight_legend = True, legend_pos=2)

def set_ZAC_amb_plot(fig, ax):
    ax.set_xscale('log')
    ax.set_xlabel(scat_vec)
    ax.set_ylabel(scat_int)
    ax.set_xlim([1e-2, 1])
    ax.set_ylim([-20, 20])

    format_plot(fig, ax, inv_x = True, is_fractal= True, xtick_pad = 13)
    
    
def set_phi_comparison_plot(fig, ax):
    ax.set_xlabel('UNIAXIAL STRESS (BAR)', labelpad = 20)
    ax.set_ylabel('APPARENT POROSITY', labelpad = 20)
    # ax.set_ylim([0.05, 0.3])
    ax.set_ylim([0.02, 0.1])
    
    format_plot(fig, ax)
    
    
def set_phi_Ro_plot(fig, ax, set_fig_size = True):
    ax.set_xlabel('VITRINITE REFLECTANCE (%)', labelpad = 1.5*scale)
    ax.set_ylabel('POROSITY (%)', labelpad = 1.5*scale)
    ax.set_xlim([0, 3])
    ax.set_ylim([-6, 18])
    
    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad = 3*scale)
    
    
def set_slope_Ro_plot(fig, ax, set_fig_size = True):
    ax.set_xlabel('VITRINITE REFLECTANCE (%)', labelpad = 1.5*scale)
    ax.set_ylabel('POWER-LAW EXPONENT', labelpad = 1.5*scale)
    ax.set_xlim([0, 3])
    ax.set_ylim([-3.5, -2.3])
    
    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad = 3*scale)

def set_coef_Ro_plot(fig, ax, set_fig_size = True):
    ax.set_xlabel('VITRINITE REFLECTANCE (%)', labelpad = 1.5*scale)
    ax.set_ylabel('POWER-LAW PREFACTOR', labelpad = 1.5*scale)
    ax.set_xlim([0, 3])
    ax.set_ylim([-4.6, -3])
    
    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad = 3*scale,
                ytick_num = 5)
   

def set_SSA_Ro_plot(fig, ax, set_fig_size = True):
    ax.set_xlabel('VITRINITE REFLECTANCE (%)', labelpad = 1.5*scale)
    ax.set_ylabel(r'SPECIFIC SURFACE AREA $\mathbf{(cm^{2}/cm^{3})}$',
                  labelpad = 1.5*scale)
    ax.set_yscale('log')
    ax.set_xlim([0, 3])
    ax.set_ylim([1e3, 1e8])
    
    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad = 3*scale)
    

def set_cross_d_Ro_plot(fig, ax, set_fig_size = True):
    ax.set_xlabel('VITRINITE REFLECTANCE (%)', labelpad = 1.5*scale)
    ax.set_ylabel('PORE SIZE AT CROSSING (nm)', labelpad = 2*scale)
    ax.set_xlim([0, 3])
    ax.set_ylim([0, 40])
    
    format_plot(fig, ax, set_fig_size= set_fig_size, xtick_pad = 3*scale)

def set_annulus_plot(fig, ax, leg_col = 1):
    ax.set_xlabel('AZIMUTHAL ANGLE \u03A6 (deg)', labelpad = 1.5*scale)
    ax.set_ylabel(scat_int, labelpad = 2*scale)
    # ylim = ax.get_yticks()
    # y_min = ylim[0]
    # y_max = (ylim[-1] - ylim[0])*0.2 + ylim[-1]
    # # ax.set_xlim([0, 3])
    # ax.set_ylim([y_min, y_max])
    
    format_plot(fig, ax, xtick_pad = 3*scale, leg_col = leg_col)
   
def set_Guinier_plot(fig, ax, lvl):
    ax.set_xlabel('$\mathbf{Q^{2}}$' + '(\u212B' + r'$\mathbf{^{-2}}$)', 
                  labelpad = 0*scale)
    ax.set_ylabel('ln[I(Q)]', labelpad = 0*scale)
    
    if '01.' in lvl:
        ax.set_xlim([0, 0.22]) # Q > 0.2 A-1 Silica Aerogel
        ax.set_ylim([-2.85, -2.4])
        # ax.set_xlim([0, 0.22]) # Q > 0.2 A-1 Silica Aerogel
        # ax.set_ylim([-5.601, -4.6])

    elif '02.' in lvl: 
        ax.set_xlim([-5e-3, 0.1]) # 0.15 < Q < 0.2 A-1 Silica Aerogel
        ax.set_ylim([-10, 2])
    elif '03.' in lvl: 
        ax.set_xlim([-1e-3, 0.03]) # 0.05 < Q < 0.15 A-1 Silica Aerogel
        ax.set_ylim([-12, 2])
    elif '04.' in lvl: 
        ax.set_xlim([-2e-4, 0.008]) # 0.03 < Q < 0.07 A-1 Silica Aerogel
        ax.set_ylim([-8, 2])
    elif '05.' in lvl: 
        ax.set_xlim([-5e-5, 2e-3]) # 0.05 < Q < 0.15 A-1 Silica Aerogel
        ax.set_ylim([-6, 6])
    elif '06.' in lvl: 
        ax.set_xlim([-5e-6, 1e-4]) # 0.05 < Q < 0.15 A-1 Silica Aerogel
        ax.set_ylim([-4, 6])
    
    format_plot(fig, ax, xtick_pad = 7*scale)
    

def set_subnano_plot(fig, ax1, ax2):
    ax1.set_xlabel('$\mathbf{CD_{4}}$' + ' PRESSURE (bar)', labelpad = 0.5*scale)
    ax1.set_ylabel('I(Q=0) ' + '$\mathbf{(cm^{-1})}$', labelpad = 0.5*scale)
    ax2.set_ylabel('CALCULATED PORE RADIUS (\u212B)', labelpad = 0.5*scale)
    
    ax1.set_ylim([0, 0.045])
    ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    
    ax2.set_ylim([0, 4.5])
    
    format_plot(fig, ax1, adj_ytick = False)
    format_plot(fig, ax2, adj_ytick = False)
    ax1.tick_params(axis='y', which='minor', left=False, right=False)
    ax2.tick_params(axis='y', which='minor', left=False, right=False)
    combine_legend((ax1, ax2), loc = 4)
    

def set_prop_v_P_plot(fig, ax1, ax2):
    ax1.set_xlabel('$\mathbf{CD_{4}}$' + ' PRESSURE (bar)', labelpad = 0*scale)
    ax1.set_ylabel('I(Q=0) ' + '$\mathbf{(cm^{-1})}$', labelpad = 0*scale)
    ax2.set_ylabel('CALCULATED PORE RADIUS (\u212B)', labelpad = 0*scale)
    
    ax1.set_ylim([0, 0.025])
    ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    
    ax2.set_ylim([5, 30])
    
    format_plot(fig, ax1, adj_ytick = False)
    format_plot(fig, ax2, adj_ytick = False)
    ax1.tick_params(axis='y', which='minor', left=False, right=False)
    ax2.tick_params(axis='y', which='minor', left=False, right=False)
    combine_legend((ax1, ax2), loc = 0)
    
    
def set_prop_v_SLD_plot(fig, ax1, ax2, lvl):
    ax1.set_xlabel(CD4_SLD, 
                   labelpad = 0*scale)
    ax1.set_ylabel('$\mathbf{\sqrt{I(Q=0)} (cm^{-\u00BD})}$', labelpad = 0*scale)
    ax2.set_ylabel('CALCULATED PORE RADIUS (\u212B)', labelpad = 0*scale)
    
    if '02.' in lvl: 
        ax1.set_ylim([0, 0.025])
        ax1.set_ylim([0.06, 0.18])
        ax2.set_ylim([10, 22])
    elif '03.' in lvl: 
        ax1.set_ylim([0, 1.2])
        ax2.set_ylim([10, 70])
    elif '04.' in lvl: 
        ax1.set_ylim([0, 1.8])
        ax2.set_ylim([-20, 160])
    elif '05.' in lvl: 
        ax1.set_ylim([0.25, 3.25])
        ax2.set_ylim([25, 325])
    elif '06.' in lvl: 
        ax1.set_ylim([6, 16])
        ax2.set_ylim([200, 1200])
    
    # ax1.ticklabel_format(style='sci', axis='y', scilimits=(0,0))
    
    format_plot(fig, ax1, adj_ytick = False)
    format_plot(fig, ax2, adj_ytick = False)
    ax1.tick_params(axis='y', which='minor', left=False, right=False)
    ax2.tick_params(axis='y', which='minor', left=False, right=False)
    combine_legend((ax1, ax2), loc = 1)


def combine_legend(ax_list, loc = 0, leg_col = 1):
    
    legend_size = 11.5*scale
    line_list = []
    label_list = []
    
    for ax in ax_list:
        line, label = ax.get_legend_handles_labels()
        line_list += line
        label_list += label
        ax.get_legend().remove()
    
    ax = ax_list[-1]        
    ax.legend(line_list, label_list, loc = loc,
              fontsize = legend_size, facecolor = 'w', 
              framealpha = 1, title_fontsize = legend_size,
              labelspacing = legend_spacing(scale), handletextpad = 1e-5*scale,
              ncol = leg_col, columnspacing = 0.01*scale)
    ax.get_legend().get_frame().set_edgecolor('k')
    ax.get_legend().get_frame().set_linewidth(0.75*scale)
    
    return ax

    
# Format plot to meet Andrzej's standard
def format_plot(fig, ax, inv_x = False, xtick_num = -1, 
                is_fractal = False, xtick_pad = 2*scale, set_fig_size = True,
                leg_col = 1, tight_legend = False, legend_pos = 1,
                adj_xtick = True, adj_ytick = True):
    tick_label_size_x = 10*scale
    tick_label_size_y = 10*scale
    axis_title_size = 13*scale
    title_size = 14*scale
    legend_size = 11.5*scale
    
    ytick_pad = 2*scale
    
    tick_length = 4*scale
    
    fig.set_dpi(100)
    fig.set_edgecolor('k')
    fig.set_facecolor('w')
    if set_fig_size:    
        fig.set_size_inches(w = 4*scale, h = 3.5*scale)
    
    fig.subplots_adjust(wspace = 0.2)
    fig.set_tight_layout(True)
    # fig.tight_layout(pad = 2)

    ax.spines[:].set_linewidth(0.75*scale)
    
    ax.title.set_fontsize(title_size)
    
    ax.xaxis.label.set_fontsize(axis_title_size)
    ax.yaxis.label.set_fontsize(axis_title_size)
    
    ax.xaxis.offsetText.set_fontsize(axis_title_size)
    ax.yaxis.offsetText.set_fontsize(axis_title_size)
    
    ax.tick_params(axis = 'x', labelsize = tick_label_size_x, 
                   pad = xtick_pad, width = 0.75*scale)
    ax.tick_params(axis = 'y', which = 'both', labelsize = tick_label_size_y,
                   pad = ytick_pad, width = 0.75*scale)
    ax.xaxis.offsetText.set_fontsize(tick_label_size_x)
    ax.yaxis.offsetText.set_fontsize(tick_label_size_y)
    
    ax.xaxis.major.formatter._useMathText = True
    ax.yaxis.major.formatter._useMathText = True

    ax.minorticks_on()
    ax.tick_params(which = 'both', direction = 'in', 
                    length = tick_length, width = 0.75*scale)
    ax.yaxis.set_tick_params(right = 'on', which = 'both', width = 0.75*scale)

   
    ax.grid(which = 'major', visible = True, 
            color = [0, 0, 0], linewidth = 0.75*scale, linestyle = 'dotted')
    
    if ax.get_legend_handles_labels()[0] != [] :
        ax.legend(fontsize = legend_size, facecolor = 'w', loc = legend_pos, 
                  framealpha = 1, title_fontsize = legend_size,
                  labelspacing = legend_spacing(scale, tight_legend), 
                  borderpad = border_padding(scale, tight_legend),
                  handletextpad = 1e-5*scale, ncol = leg_col, 
                  columnspacing = 0.01*scale)
        ax.get_legend().get_frame().set_edgecolor('k')
        ax.get_legend().get_frame().set_linewidth(0.75*scale)
        
    
    if inv_x == True:
        ax2 = ax.twiny()
        ax.set_zorder(1)
        ax2.set_zorder(2)
        ax.patch.set_alpha(0)
        
        ax2.set_xscale(ax.get_xscale())
        ax2.xaxis.set_major_formatter(ticker.FuncFormatter(lambda y, _: '{:g}'.format(y)))
        ax2.xaxis.label.set_fontsize(axis_title_size)
        ax2.tick_params(which = 'both', direction = 'in', length = tick_length, 
                        labelsize = tick_label_size_x, pad = xtick_pad,
                        width = 0.75*scale, zorder = 1)
        
        ax_xlim = ax.get_xlim()
        
        if not is_fractal:
            ax2.set_xlim(.1/np.array(ax_xlim))
            ax2.set_xlabel('PORE DIAMETER D = 2/Q (nm)', labelpad = 5*scale)
        else:
            # ax_xtick = ax.get_xticks()
            # ax_xtick = ax_xtick[np.logical_and(ax_xtick >= ax_xlim[0],
            #                                    ax_xtick <= ax_xlim[1])]

            ax2.set_xlim(0.1/np.array(ax_xlim))
            # ax2.set_xticks(ax_xtick)
            ax2.set_xticklabels(['{:g}'.format(2.5*val)
                                 for val in ax2.get_xticks()])
            ax2.set_xlabel('PORE RADIUS = 2.5/Q (nm)', labelpad = 5*scale)
        
    else:
        ax.xaxis.set_tick_params(top = 'on', which = 'both')
        
        
    def adj_tick(ax, axis):
        if axis == 'x':
            xyscale = ax.get_xscale()
            xylim = ax.get_xlim()
        elif axis == 'y':
            xyscale = ax.get_yscale()
            xylim = ax.get_ylim()
            
        if xyscale == 'log':
            xylim = np.log10(xylim)

        xy_max = np.max(xylim)
        xy_min = np.min(xylim)
        xy_span = xy_max - xy_min
        
        if xyscale == 'linear' or xy_span > 5:
            xy_span_convert = xy_span/10**(np.floor(np.log10(xy_span)))
            xy_min_convert = xy_min/10**(np.floor(np.log10(xy_span)))
            
            if xy_span_convert < 1.6:
                xytick_space_convert = 0.2
            elif xy_span_convert < 2.5:
                xytick_space_convert = 0.4
            elif xy_span_convert < 4:
                xytick_space_convert = 0.5
            elif xy_span_convert < 8:
                xytick_space_convert = 1
            else:
                xytick_space_convert = 2
                
            if xy_min_convert % xytick_space_convert != 0:
                xy_min_used_convert = ((xy_min_convert + xytick_space_convert) - 
                                       (xy_min_convert % xytick_space_convert))
            else:
                xy_min_used_convert = xy_min_convert
                
            xytick_space = xytick_space_convert*10**(np.floor(np.log10(xy_span)))
            xy_min_used = xy_min_used_convert*10**(np.floor(np.log10(xy_span)))
            xyticks_used = np.arange(xy_min_used, xy_max+xytick_space/2, xytick_space)
            
            if xyscale == 'log':
                if xy_min_used > 0 or xy_max < 0:
                    tick_list = 10**(xyticks_used)
                else:
                    tick_list = np.append(10**(xyticks_used), 1)
                    
                if axis == 'x':
                    ax.set_xticks(tick_list)
                elif axis == 'y':
                    ax.set_yticks(tick_list)
            else:
                if axis == 'x':
                    ax.set_xticks(xyticks_used)
                elif axis == 'y':
                    ax.set_yticks(xyticks_used)
            
    if adj_xtick:
        adj_tick(ax, axis = 'x')
    if adj_ytick:
        adj_tick(ax, axis = 'y')


def format_contour_plot(fig, ax, cp, yticks, cbar_label, cbar_label_pad = 0):
    
    cbar_major_tick_len = 3*scale
    cbar_major_tick_wid = 0.4*scale
    cbar_minor_tick_len = 2*scale
    cbar_minor_tick_wid = 0.3*scale
    
    fig.tight_layout(rect = (0,0,0.97,1))
    ax.grid(axis = 'both', which = 'major', linewidth = 0.4*scale)
    ax.tick_params(axis = 'x', which = 'both', direction = 'out')
    ax.tick_params(axis = 'y', which = 'both', direction = 'out', right = False)
    ax.tick_params(axis = 'x', which = 'minor', length = 3*scale, width = 0.5*scale)
    if len(fig.get_axes()) > 1:
        ax1 = fig.get_axes()[1]
        ax1.tick_params(axis = 'x', which = 'both', direction = 'out', pad = 0.1*scale)
        ax1.tick_params(axis = 'x', which = 'minor', length = 3*scale, width = 0.5*scale)
    ax.tick_params(axis = 'y', which = 'minor', length = 3*scale, width = 0.5*scale)
    ax.tick_params(axis = 'y', which = 'minor', right = False)
    ax.set_yticks(yticks)
    cbar = fig.colorbar(cp, pad = 0.04*scale)

    cbar.ax.set_ylabel(cbar_label, fontsize = axis_label_font_size, rotation = -90,
                       labelpad = cbar_label_pad)
    
    cbar_lim = cbar.ax.get_ylim()
    base_list = np.float_power(10, 
                               np.array(range(int(np.ceil(np.log10(np.min(cbar_lim)))),
                                              int(np.floor(np.log10(np.max(cbar_lim))))+1)))
    if len(base_list) <= 4:
        
        cbar.ax.tick_params(labelsize=value_label_font_size, 
                            width = cbar_minor_tick_wid, 
                            length = cbar_minor_tick_len, direction = 'in') 
        
        low_pow_lim = np.floor(np.log10(np.min(cbar_lim)))
        hi_pow_lim = np.ceil(np.log10(np.max(cbar_lim)))
        
        pow_list = np.float_power(10, np.array(range(int(low_pow_lim), 
                                                     int(hi_pow_lim)+1)))
        
        label_list = np.multiply.outer(pow_list, np.array(range(1,10))).ravel()
        label_list = label_list[np.logical_and(label_list >= np.min(cbar_lim), 
                                               label_list <= np.max(cbar_lim))]
        
        base_pos_start = np.where(np.log10(label_list)%1 == 0)[0][0]
        base_pos_list = np.arange(base_pos_start, len(label_list), 9)

        cbar.ax.set_yticks(label_list,
                            ['$10^{{{:.0f}}}$'.format(num) 
                            for num in np.log10(label_list)])
        
        plt.setp(np.delete(cbar.ax.get_yticklabels(), 
                           base_pos_list), visible=False)
        [cbar.ax.yaxis.get_major_ticks()[tick_pos].tick2line.
                                         set_markersize(cbar_major_tick_len) 
                                         for tick_pos in base_pos_list]
        [cbar.ax.yaxis.get_major_ticks()[tick_pos].tick2line.
                                     set_markeredgewidth(cbar_major_tick_wid) 
                                     for tick_pos in base_pos_list]
        
    
    else:
        cbar.ax.tick_params(labelsize=value_label_font_size, 
                            width = cbar_major_tick_wid,
                            length = cbar_major_tick_len, direction = 'in') 
        
        if len(base_list) >= 8:
            base_list = base_list[::2]

        cbar.ax.set_yticks(base_list,
                            ['$10^{{{:.0f}}}$'.format(num) 
                            for num in np.log10(base_list)])


    
# Display figure on top
def show_figure():
    plt.gcf()
    plt.draw()
    plt.tight_layout()
    plt.show()
    
    k = 0
    while k != True:
        k = plt.waitforbuttonpress()
        