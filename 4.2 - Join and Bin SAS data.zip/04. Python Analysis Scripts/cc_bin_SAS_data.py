# -*- coding: utf-8 -*-
"""
Created on Fri Mar  7 19:42:52 2025

@author: NHUHA
"""

import numpy as np
import pathlib as pl
import scipy.interpolate as itp

import zz_supported_functions as sp
import zz_plot_formating as pf

import matplotlib
matplotlib.use('Qt5Agg')


# Class for binning SAS data
class bin_SAS_data(sp.FrozenClass):
    
    def __init__(self):
        
        # Set up working directory
        dir_parent = pl.Path().resolve().parent
        self.dir_result = dir_parent / '03. Analysed Result'
        self.dir_combined_data = self.dir_result / '02. Data Joined'
        self.dir_binned_data = self.dir_result / '03. Data Binned'
        self.dir_fig_binned_data = self.dir_result / 'cc. Figure Binned Data'
        self.dir_fig_binned_data_comparison = \
            self.dir_result / 'cc. Figure Combined Data vs. Binned Data'
        
        # Assign working variable
        self.Q_max_USANS = 1.2e-3       # Q value separating SANS and USANS
        self.num_pts_per_dec_SANS = 15  # Number of pts per dec for binned SANS
        self.num_pts_per_dec_USANS = 7  # Number of pts per dec for binned USANS

        # Prevent new attributes from being added
        self._freeze()
            
    def run_program(self):
        for file_path in self.dir_combined_data.iterdir():
            self.bin_data(file_path)
        
    def bin_data(self, file_path):
        # Read data from joined data file
        with open(file_path) as file:
            file_data = file.readlines()
            file_header = file_data[1:3]
            joined_SAS_data = np.array([line.split() for line in file_data[3:]], 
                                        float)
        # Assign working variables
        binned_SAS_data = []
        
        # Sort SAS data in ascending order of Q values
        Q_val = joined_SAS_data[:,0]
        sorted_idx = np.argsort(Q_val)
        joined_SAS_data = joined_SAS_data[sorted_idx]

        # Get Q min and Q max
        Q_range = joined_SAS_data[:,0]
        logQ_range = np.log10(Q_range)
        logQ_min = np.min(logQ_range)
        logQ_max = np.max(logQ_range)
        
        # Create a list of evenly spaced Q values in log scale in USANS range
        logQ_min_USANS_rounded = np.floor(logQ_min)
        logQ_max_USANS_rounded = np.ceil(np.log10(self.Q_max_USANS))
        logQ_dist_USANS = 1/self.num_pts_per_dec_USANS
        logQ_ideal_USANS = np.arange(logQ_min_USANS_rounded, 
                                     logQ_max_USANS_rounded + logQ_dist_USANS/2, 
                                     logQ_dist_USANS)
        logQ_ideal_USANS_min_idx = np.where(logQ_ideal_USANS < logQ_min)[0][-1]
        logQ_ideal_USANS_max_idx = np.where(logQ_ideal_USANS > np.log10(self.Q_max_USANS))[0][0]
        logQ_ideal_USANS = logQ_ideal_USANS[logQ_ideal_USANS_min_idx:
                                            logQ_ideal_USANS_max_idx+1]
        
        # Create a list of evenly spaced Q values in log scale in SANS range
        logQ_min_SANS = np.floor(np.log10(self.Q_max_USANS))
        logQ_max_SANS = np.ceil(logQ_max)
        logQ_dist_SANS = 1/self.num_pts_per_dec_SANS
        logQ_ideal_SANS = np.arange(logQ_min_SANS,
                                    logQ_max_SANS + logQ_dist_SANS/2,
                                    logQ_dist_SANS)
        logQ_ideal_SANS_min_idx = np.where(logQ_ideal_SANS > np.max(logQ_ideal_USANS))[0][0]
        logQ_ideal_SANS_max_idx = np.where(logQ_ideal_SANS > logQ_max)[0][0]
        logQ_ideal_SANS = logQ_ideal_SANS[logQ_ideal_SANS_min_idx:
                                          logQ_ideal_SANS_max_idx+1]
        
        # Join the evenly-spaced Q list in SANS and USANS range
        logQ_ideal = np.concatenate((logQ_ideal_USANS[:-1], logQ_ideal_SANS))
        logQ_interp = (logQ_ideal[:-1] + np.diff(logQ_ideal)/2)[1:-1]
            
        # Bin data
        log_data = np.log10(joined_SAS_data)
        for i in range(len(logQ_ideal)-1):
            # Obtain data between every two evenly-spaced Q values
            logQ_min = logQ_ideal[i]
            logQ_max = logQ_ideal[i+1]
            data_in_range = log_data[np.logical_and(log_data[:,0] >= logQ_min,
                                                    log_data[:,0] < logQ_max)]
            
            # If more than two data points exist within each Q interval,
            # compute the average of Q, IQ, dIQ;
            # otherwise, retain the original values
            if len(data_in_range[:,0]) > 0:
                if len(data_in_range[:,0]) >= 2:
                    logQ_binned = np.average(data_in_range[:,0])
                    logIQ_binned = np.average(data_in_range[:,1])
                    log_dIQ_binned = np.log10(np.sqrt(np.sum((10**data_in_range[:,2])**2))
                                              /len(data_in_range[:,2]))
                else:
                    logQ_binned = data_in_range[:,0]
                    logIQ_binned = data_in_range[:,1]
                    log_dIQ_binned = data_in_range[:,2]
                    
                new_entry = np.column_stack((10**logQ_binned, 
                                             10**logIQ_binned, 
                                             10**log_dIQ_binned))
                binned_SAS_data.append(new_entry)
            else:
                logQ_interp = np.delete(logQ_interp, i-1)
        
        # Position the binned IQ values at the midpoint of each Q interval
        # by first interpolating the IQ values, then extracting the IQ values
        # at the midpoint Q value from the interpolation function
        binned_SAS_data = np.row_stack(binned_SAS_data)
        interp_func_IQ = itp.CubicSpline(np.log10(binned_SAS_data[:,0]),
                                             np.log10(binned_SAS_data[:,1]))
        logIQ_interp = interp_func_IQ(logQ_interp)
        log_dIQ_interp = logIQ_interp + np.log10((binned_SAS_data[1:-1,2]/
                                                  binned_SAS_data[1:-1,1]))
        
        binned_SAS_data = 10**np.column_stack((logQ_interp, logIQ_interp, 
                                               log_dIQ_interp))

        # Print some fitting information
        print('Q min combined = {:.3e}'.format(joined_SAS_data[0,0]))
        print('Q max combined = {:.3e}'.format(joined_SAS_data[-1,0]))
        print('Q min binned = {:.3e}'.format(10**logQ_interp[0]))
        print('Q max binned = {:.3e}\n'.format(10**logQ_interp[-1]))

        # Plot combined data vs binned data
        Q_combined = joined_SAS_data[:,0]
        IQ_combined = joined_SAS_data[:,1]
        Q_binned = binned_SAS_data[:,0]
        IQ_binned = binned_SAS_data[:,1]

        fig, ax = pf.new_plot()
        ax.plot(Q_combined, IQ_combined, '.r', markersize = 5*pf.scale, label = 'Combined Data')
        ax.plot(Q_binned, IQ_binned, 'ob', markersize = 6*pf.scale, alpha = 0.3, label = 'Binned Data')

        ax.set_xscale('log')
        ax.set_yscale('log')
        ax.set_xlabel(pf.scat_vec, labelpad = -1.5*pf.scale)
        ax.set_ylabel(pf.scat_int, labelpad = -0.5*pf.scale)
        
        pf.format_plot(fig, ax, inv_x = True, 
                        is_fractal= True, xtick_pad = 4*pf.scale)
        sp.save_plot(fig, file_path.parts[-1], self.dir_fig_binned_data_comparison)
        
        # Save result
        if not self.dir_binned_data.exists():
            self.dir_binned_data.mkdir()
        result_save_path = self.dir_binned_data / file_path.parts[-1]

        with open(result_save_path, 'w') as file:
            file.write('Binned Scattering Data\n')
            [file.write(line) for line in file_header]
            [file.write('\t'.join("{:.5e}".format(val) for val in line)+'\n') 
             for line in binned_SAS_data]

def main():
    bin_data = bin_SAS_data()
    bin_data.run_program()
    
if __name__ == '__main__':
    main()
