# -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 14:39:07 2020

@author: NHUHA
"""

import pathlib as pl
import numpy as np

import zz_supported_functions as sp
import zz_plot_formating as pf


# Class containing information for segmented SAS data
class raw_SAS_data(sp.FrozenClass):
    
    def __init__(self, sample_name = None, instrument_config = None, 
                 sample_condition = None, CD4_pressure = None, 
                 original_file_name = None, wave_length = None):
        
        self.sample_name = sample_name if sample_name != None else []
        self.instr_config = instrument_config if instrument_config != None else []
        self.CD4_pressure = CD4_pressure if CD4_pressure != None else []
        self.sample_cond = sample_condition if sample_condition != None else []
        self.original_file_name = original_file_name if original_file_name != None else []
        self.wave_length = wave_length if wave_length != None else []
        self.data = []
        self.file_name = None
        self._freeze()


# This class read output data from SAS instruments, rewrite them in a consistent
# format for later analysis steps
class process_raw_data(sp.FrozenClass):

    def __init__(self):
        
        # Set up working directory
        dir_parent = pl.Path().resolve().parent
        self.dir_raw_SANS = dir_parent / '01. Quokka SANS Outputs'
        self.dir_raw_USANS = dir_parent / '02. Kookaburra USANS Outputs - Desmeared'
        self.dir_result = dir_parent / '03. Analysed Result'
        self.dir_raw_data_organised = self.dir_result / '01. Data Unanalysed'
        self.dir_fig_raw_data = self.dir_result / 'aa. Figures Raw Data'
        
        # Name of sample for the rewritten ASCII files
        self.sample_name = 'HC_L4_L2'
        
        # Properties of SAS output data
        self.num_config_SANS = 4    # number of SANS configuration
        self.num_header_SANS = 14   # number of header rows in SANS data file 
        self.num_config_USANS = 1   # number of USANS configuration
        self.num_header_USANS = 4   # number of header rows in USANS data file
        
        # Specify the location for the script to find the necessary details  
        # contained within the data file. The instructions inside the square  
        # brackets can be read as:  
            # (i)   Location of the information, such as file name or header  
            # (ii)  Row number containing the specified information  
            # (iii) Delimiter used to split the selected row into smaller text blocks  
            # (iv)  Position (index) of the text block obtained in step (iii)
        self.pos_config_SANS = ['header', 3, None, (3,), ''] # SANS configuration
        self.pos_wave_length = ['header', 3, None, (1,)]     # neutron wavelength
        self.pos_pH2O_SANS = ['header', 1, '_', (4,)]        # uniaxial pressure
        self.pos_pCD4_SANS = ['header', 1, '_', (3,)]        # hydrostatic pressure
        
        # Assign working variables
        self.SAS_data_list = []
        self.sample_condition = []
        self.pH2O = None
        self.pCD4 = None
        self.destress = None
        self.SAS_seg_list = []
        self.sample_save_name = None
        
        # Prevent new attributes from being added
        self._freeze()

    # Execute program
    def run_program(self):
        num_runs = len(list(self.dir_raw_SANS.iterdir()))/self.num_config_SANS
        if abs(num_runs - int(num_runs)) < 0.001:
            num_runs = int(num_runs)
        else:
            raise ValueError('Number of unanalysed SANS files not divisible by ' 
                        + str(self.num_config_SANS))

        for i in range(num_runs):
            print('File num: ', i+1)
            self.get_data(i,i)
            self.write_data(file_idx = i+1)
            self.get_raw_SAS_data(i)
            self.plot_raw_data()

    # This function is used to acquire the raw SANS and USANS data in ASCII files
    def get_data(self, SANS_choice = None, USANS_choice = None):
        
        # Display the list of files available for SANS and USANS by calling
        # function show_file_list
        cond_list, file_list_SANS, file_list_USANS = self.get_file_list()
        
        # Check if the experiment contains SANS data, if yes then get the SANS
        # data using function get_data_SANS, then add the data to the list of
        # SAS data
        if self.num_config_SANS > 0:
            data_SANS = self.get_data_SANS(cond_list, file_list_SANS, SANS_choice)
            self.SAS_data_list.extend(data_SANS)
            
        # Check if the experiment contains USANS data, if yes then get the USANS
        # data using function get_data_USANS, then add the data to the list of
        # SAS data
        if self.num_config_USANS > 0:          
            data_USANS = self.get_data_USANS(file_list_USANS, USANS_choice)
            self.SAS_data_list.append(data_USANS)
        
    # This function is also used to obtain the file list for SANS and USANS
    # experiment and extract the experimental condition
    # This function is used by get_data
    def get_file_list(self):
        
        # Show file list of SANS if there are SANS data in the experiment. 
        # The program group all the SANS files of different sample-detector
        # by the condition where the experiment was conducted
        # The condition of which the experiment was conducted can be acquired 
        # using function get_SANS_cond_list
        file_list_SANS = np.array(list(self.dir_raw_SANS.iterdir()))
        file_list_SANS = file_list_SANS.reshape((-1,self.num_config_SANS))    
        cond_list = self.get_SANS_cond_list(file_list_SANS[:,0])
        cond_list = self.change_duplicated_cond(cond_list)
            
        # Similar to the SANS procedure, but for USANS data
        file_list_USANS = np.array(list(self.dir_raw_USANS.iterdir()))
        
        return cond_list, file_list_SANS, file_list_USANS 

    # Retrieve SANS data under specific conditions across all sample-detector distances  
    # The code contains unnecessary intermediate steps as it was adapted from  
    # a larger program for demonstration purposes 
    def get_data_SANS(self, cond_list, file_list, SANS_choice):
        
        # Confirm selected experimental condition
        chosen_cond = SANS_choice
        self.sample_condition = cond_list[chosen_cond]        
        file_names = np.array(file_list[chosen_cond, :])
        
        # Get SANS data corresponding to the selected condition
        SANS_data_list = []
        for i in range(len(file_names)):
            
            SANS_data = raw_SAS_data()
            SANS_data.sample_name = self.sample_name
            SANS_data.original_file_name = file_names[i].parts[-1]
            
            strip_char = self.pos_config_SANS[4]
            
            SANS_config, _ = self.get_cond(self.pos_config_SANS, file_names[i])
            SANS_config = SANS_config.replace("Dist", "")
            SANS_config = SANS_config.strip(strip_char) 
            SANS_config = ((str(round(float(SANS_config),2)) 
                            if float(SANS_config) < 2
                            else str(int(float(SANS_config)))) + 'm')
            wave_len, _ = self.get_cond(self.pos_wave_length, file_names[i])
            wave_len = wave_len.replace("WavL","")
            if abs(float(wave_len) - 5) > abs(float(wave_len) - 8.1):
                SANS_config = 'lens'
            
            SANS_data.instr_config = ('SANS-' + SANS_config)

            with open(self.dir_raw_SANS / file_names[i]) as file:
                file_data = file.readlines()
                
            SANS_data.data = [cur_line.replace('\n','').replace(',','\t').split() 
                              for cur_line in file_data[self.num_header_SANS:]]
            SANS_data.data = np.array(SANS_data.data, dtype = float)
            
            is_negative = SANS_data.data[:,1] < 0
            if any(is_negative):
                negative_idx = np.where(is_negative)[0]
                SANS_data.data = np.delete(SANS_data.data, negative_idx, axis = 0)
                
            is_large_err = SANS_data.data[:,2]/SANS_data.data[:,1] > 0.5
            if any(is_large_err):
                large_err_idx = np.where(is_large_err)[0]
                SANS_data.data = np.delete(SANS_data.data, large_err_idx, axis = 0)

            SANS_data_list.append(SANS_data)
            
        return SANS_data_list
        
    # This function extract the condition of which the experiment was conducted
    # This function is used by get_file_list
    def get_SANS_cond_list(self, file_list):
        
        sample_condition_list = []
    
        for i in range(len(file_list)):
            sample_condition = []
            
            header_data_pH2O, have_des = self.get_cond(self.pos_pH2O_SANS,
                                                       file_list[i])
            sample_condition.append(header_data_pH2O.replace('bar','')
                                    .replace('P','').replace('H2O', '') 
                                    + 'H2O')
            
            header_data_pCD4, _ = self.get_cond(self.pos_pCD4_SANS, 
                                                file_list[i])
            header_data_pCD4 = header_data_pCD4.replace("vac", "0")
            sample_condition.append(header_data_pCD4.replace('bar','')
                                    .replace('Air','').replace('AIR','')
                                    .replace('CD4','') + 'CD4')
            
            if len(sample_condition) == 1:
                sample_condition = sample_condition[0]
            else:
                sample_condition = '_'.join(sample_condition)
            sample_condition_list.append(sample_condition)
                
        return np.array(sample_condition_list, dtype = 'U20')
       
    # Get experimental conditino from file name
    def get_cond(self, pos_info, file_name):
        if pos_info[0] == 'header':
            line_num = pos_info[1]
            strip_list = pos_info[2:]
            
            with open(self.dir_raw_SANS / file_name) as file:
                #extract the string element containing the pressure data
                header_data = file.readlines()[line_num].strip('\n')
                have_des = True if 'des' in header_data else False
                
                for i in range(int(len(strip_list)/2)):
                    header_data = header_data.split(strip_list[i*2])
                    if len(strip_list[i*2+1]) == 1:
                        header_data = header_data[strip_list[i*2+1][0]]
                    elif len(strip_list[i*2+1]) == 2:
                        header_data = header_data[strip_list[i*2+1][0]:
                                                  strip_list[i*2+1][1]]
                            
        return header_data, have_des

    # This function change the sample name in case the condition was duplicated
    def change_duplicated_cond(self, cond_list):
        
        unique_conds = np.unique(cond_list)
        
        for current_cond in unique_conds:
            curr_cod_pos = np.where(current_cond == cond_list)[0]
            
            if len(curr_cod_pos) > 1:
                for idx in range(len(curr_cod_pos))[1:]:
                    cond_list[curr_cod_pos[idx]] += '_des'
                    
        return cond_list

    # Extracting USANS data
    def get_data_USANS(self, file_list, USANS_choice):
        
        if USANS_choice == None:
            chosen_sample = input('PLEASE CHOOSE A USANS DATA FILE (0-'
                                  + str(len(file_list)-1) + '): ')
            chosen_sample = 0 if chosen_sample == '' else int(chosen_sample)
        
        else: chosen_sample = USANS_choice
        
        if chosen_sample not in range(len(file_list)):
            raise ValueError('\nThe chosen file for USANS has to be in ' + 
                             'between 0 and {:d}\n'.format(len(file_list)-1) + 
                             'Current option value: {:d}'.format(chosen_sample))
        
        chosen_file = file_list[chosen_sample]    
        
        USANS_data = raw_SAS_data()
        USANS_data.sample_name = self.sample_name
        USANS_data.original_file_name = chosen_file.parts[-1]
        USANS_data.instr_config = 'USANS'
        
        with open(self.dir_raw_USANS / chosen_file) as file:
            file_data = file.readlines()
            
        USANS_data.data = [cur_line.strip('\n').split() 
                           for cur_line in file_data[self.num_header_USANS:]]
        USANS_data.data = np.array(USANS_data.data, dtype = float)
        
        is_negative = USANS_data.data[:,1] < 0
        if any(is_negative):
            negative_idx = np.where(is_negative)[0]
            USANS_data.data = np.delete(USANS_data.data, negative_idx, axis = 0)
            
        return USANS_data
    

    # Write the raw data in a more organized manner for future analysis    
    def write_data(self, file_idx = None):
        
        if not self.dir_raw_data_organised.exists():
            self.dir_raw_data_organised.mkdir()

        for i, SAS_data in enumerate(self.SAS_data_list):
            if self.sample_name != '':
                file_name = '_'.join([self.sample_name, self.sample_condition,
                                          SAS_data.instr_config]) + '.txt'
            else:
                file_name = '_'.join([self.sample_condition,
                                      SAS_data.instr_config]) + '.txt'
            
            if file_idx is not None:
                file_name = '{:0>2d}. '.format(file_idx) + file_name
                
            file_dir = self.dir_raw_data_organised / file_name

            with open(file_dir, 'w') as file:
                file.write('Original file name:\n' + 
                           SAS_data.original_file_name + '\n')
                file.write('Segment Q-range:\n')
                file.write('0\t1\n')
                file.write('Alignment factor:\n')
                file.write('1\n')
                file.write('\n')
                
                [file.write('\t'.join(['{:.5e}'.format(val) for val in line]) 
                            +'\n') for line in SAS_data.data]
                
    # Read the data from 1. Data Unanalysed and store the result in raw_SAS_data
    # This function is used for plotting purposes
    def get_raw_SAS_data(self, chosen_file):
        
        # Obtain the list of file in the Data Unanalysed directory
        file_list = (np.array(list(self.dir_raw_data_organised.iterdir())).
                     reshape((-1,self.num_config_SANS+self.num_config_USANS)))
        
        chosen_file_list = file_list[chosen_file, :]
        instr_config_list = []
        self.SAS_seg_list = []

        # After the choice has been made, assign the sample name and the
        # experimental conditon to name the result file in the future
        sample_info = chosen_file_list[0].parts[-1].replace('.txt','').split('_')
        self.pH2O = [pH2O for pH2O in sample_info
                     if 'H2O' in pH2O][0].replace('H2O','')
        self.pCD4 = [pCD4 for pCD4 in sample_info
                     if 'CD4' in pCD4][0].replace('CD4','')
        self.destress = True if 'des' in sample_info else False
        
        # Assign the file_name, SANS/USANS instrument config to class raw_SAS_data
        # After the data has been obtained from the unanalysed files and
        # appended into the 
        for file_name in chosen_file_list:
            segment_info = file_name.parts[-1].replace('.txt','').split('_')

            file_dir = self.dir_raw_data_organised / file_name
            
            with open(file_dir) as file:
                file_data = file.readlines()
            
            # Data obtainable from file name
            SAS_seg_data = raw_SAS_data()
            SAS_seg_data.file_name = file_name.parts[-1]
            instr_config = [instr_config for instr_config in segment_info
                            if ('SANS' in instr_config or 
                                'USANS' in instr_config)][0]
            SAS_seg_data.instr_config = instr_config
            instr_config_list.append(instr_config)  # for sorting the SAS segment
                                                    # a correct order
            
            # Data obtainable from data header
            SAS_seg_data.data = np.array([cur_line.strip('\n').split() 
                                          for cur_line in file_data[7:]], float)
            
            # Append the current segment to the list of scattering segments
            self.SAS_seg_list.append(SAS_seg_data)
        
        # Sort each SANS segment in SAS_seg_list in the order of increasing 
        # detector distance, follows by the USANS segment
        instr_config_stripped = []
        
        # Get the sample-detector distance from the list of SANS config
        for instr_config in instr_config_list:
            if not 'USANS' in instr_config:
                instr_config = instr_config.replace('SANS-','').replace('m','')
                if instr_config == 'SANS':
                    instr_config = 1 # For the case of only one SANS file such as Bilby
                else:
                    try: instr_config = float(instr_config)
                    except: pass
            instr_config_stripped.append(instr_config)
        
        # Put v-SANS segment at the second last position
        try:
            lens_idx = instr_config_stripped.index('lens')
            instr_config_stripped[lens_idx] = 99
        except:
            pass

        # Put the USANS segment at the final position
        try:
            USANS_idx = instr_config_stripped.index('USANS')
            instr_config_stripped[USANS_idx] = 100
        except:
            pass
        
        # Sort the different scattering segment by the order of decreasing
        # Q-range
        sorted_config_idx = sorted(range(len(instr_config_stripped)), 
                                   key=instr_config_stripped.__getitem__)
        self.SAS_seg_list = [self.SAS_seg_list[idx] 
                             for idx in sorted_config_idx]
        
        self.sample_save_name = sample_info[0].split()[0] + ' ' + self.sample_name
        self.sample_save_name += '_' + self.pH2O + 'H2O'
        self.sample_save_name += '_' + self.pCD4 + 'CD4'
        self.sample_save_name += '_des' if 'des' in sample_info else ''

    # This function plot the unaltered data coming from the instrument
    def plot_raw_data(self):
        
        fig, ax = pf.new_plot()
        marker_style = pf.get_marker_list_short()[:self.num_config_SANS
                                                  +self.num_config_USANS]
        
        # for each segment in SAS_seg_list, get the Q, IQ and std value and plot
        for i in range(len(self.SAS_seg_list)):
            Q_val = self.SAS_seg_list[i].data[:,0]
            IQ_val = self.SAS_seg_list[i].data[:,1]
            error_val = self.SAS_seg_list[i].data[:,2]
            plot_label = self.SAS_seg_list[i].instr_config
            
            ax.plot(Q_val, IQ_val, marker_style[i], label= plot_label)
            ax.errorbar(Q_val, IQ_val, yerr=error_val,
                        marker = '', linestyle = '', ecolor = marker_style[i][1], 
                        elinewidth=pf.marker_scale*2, capsize=pf.scale*2)

        pf.set_SAS_plot(fig, ax, is_fractal = True, tight_legend=True)    
        
        # Save figure, the save path is created by create_save_path
        sp.save_plot(fig, self.sample_save_name, self.dir_fig_raw_data)


def main():
    get_raw_data = process_raw_data()
    get_raw_data.run_program()
    

if __name__ == "__main__":
    main()
    