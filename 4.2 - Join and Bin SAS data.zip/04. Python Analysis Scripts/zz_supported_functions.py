# -*- coding: utf-8 -*-
"""
Created on Wed Jan  8 18:47:21 2020

@author: NHUHA
"""

import numpy as np
import warnings
import os
import random
import math
import scipy.interpolate as itp


warnings.filterwarnings('ignore')



# dir_working = \
#     r'C:\Users\NHUHA\OneDrive - UNSW\Projects\2022-06 PhD Thesis\03. Software\00. Demo Data\HC_L4_L2'

# if True:
#     if not os.path.exists(dir_working + '\\' + 'inputs.txt'):
#         raise FileNotFoundError('File inputs.txt does not exist in the working directory')
#     with open(dir_working + '\\' + 'inputs.txt') as file:
#         input_content = file.readlines()
        
#     sample_name = input_content[1].replace('\n','')
    
#     default_Q_range = []
#     for Q_range_str in input_content[15].split('||'):
#         Q_range = [float(val) for val in Q_range_str.split()]
#         default_Q_range.append((min(Q_range), max(Q_range)))
#     default_Q_range = tuple(default_Q_range[::-1])  
    
#     config_to_align = input_content[17].replace('\n','')
    
#     num_config_SANS = int(input_content[7].replace('\n',''))
#     num_config_USANS = int(input_content[9].replace('\n',''))
#     num_header_row_SANS = int(input_content[11].replace('\n',''))
#     num_header_row_USANS = int(input_content[13].replace('\n',''))
    
#     QQ_max = float(input_content[19].replace('\n',''))
#     thickness_correction_factor = float(input_content[21].replace('\n',''))
    
#     Q_range_4_USANS_alignment = [float(val) 
#                                  for val in input_content[23].replace('\n','').split()]
#     Q_range_combined_data = [float(val) 
#                              for val in input_content[25].replace('\n','').split()]
    
#     dir_raw_SANS = input_content[3].strip('\n')
#     dir_raw_USANS = input_content[5].strip('\n')

#     dir_unanalysed = dir_working + r'\01. Data Unanalysed'
    
#     dir_analysed = dir_working + r'\02. Data Analysed'
#     dir_manual = dir_analysed + r'\00. Manual Calculation Result'
#     dir_thinned = dir_analysed + r'\01. Thinned Data'
#     dir_combined = dir_analysed + r'\01b. Combined Data'
#     dir_data_no_bkgrd = dir_analysed + r'\01c. Background-Subtracted Data'
#     dir_PRINSAS_result = dir_analysed + r'\02. PRINSAS Result'
#     dir_SLD_v_r = dir_analysed + r'\02b. SLD vs r'
#     dir_accessibility = dir_analysed + r'\03. Pore Accessibility'
#     dir_ZAC_amb = dir_analysed + r'\4.(ZAC-amb)x100'
#     dir_phi = dir_analysed + r'\05. Porosity Result'
#     dir_Qinv_phi = dir_phi + r'\01. Porod Invariant Porosity'
#     dir_PRINSAS_phi = dir_phi + r'\02.PRINSAS Porosity'
#     dir_slope_SAS = dir_analysed + r'\06. Apparent Power-Law Slope for SAS data'
#     dir_slope_fr = dir_analysed + r'\07. Apparent Power-Law Slope for f(r)'
#     dir_interp_SSA = dir_analysed + r'\08. Extrapolated SSA Values'
#     dir_crossing_d = dir_analysed + r'\09. Amb-ZAC Crossing Diameter'
#     dir_fractal_fit = dir_analysed + r'\10. Fractal Fit Result'
#     dir_Guinier_fit = dir_analysed + r'\11. Guinier Fit Result'
#     dir_unified_fit = dir_analysed + r'\12. Unified Model Fit Result'
    
#     dir_fig_raw = dir_working + r'\03. Plot Raw Data'
#     dir_fig_aligned = dir_working + r'\04. Plot Aligned Data'
#     dir_fig_thinned = dir_working + r'\05. Plot Thinned Data'
#     dir_fig_thinned_align = dir_working + r'\06. Plot Thinned Data vs Aligned Data'
#     dir_fig_SAS_comparison = dir_working + r'\07. Plot SAS data at Different Conditions'
#     dir_fig_no_bkgrd = dir_working + r'\08. Plot Background Subtracted SAS Data'
#     dir_fig_fr_SSA = dir_working + r'\09. Plot f(r) and SSA over R'
#     dir_fig_dV_on_dr = dir_working + r'\10. Plot dV over dr'
#     dir_fig_F_a_r = dir_working + r'\11. Plot Fa(r)'
#     dir_fig_ZAC_amb = dir_working + r'\12. Plot (ZAC-amb)x100'
#     dir_fig_phi_comparison = dir_working + r'\13. Plot Porosity Comparison'
#     dir_fig_SAS_amb_ZAC = dir_working + r'\14. Plot SANS Start vs. End'
#     dir_fig_fr_SSA_amb_ZAC = dir_working + r'\15. Plot f(r) SSA Start vs. End'
#     dir_fig_dV_dr_amb_ZAC = dir_working + r'\16. Plot dV over dr Start vs. End'
#     dir_fig_Fa_r_start_end = dir_working + r'\17. Plot Fa(r) Start vs. End'
#     dir_fig_prop_Ro = dir_working + r'\18. Plot Properties as Fuctions of Ro'
#     dir_fig_SSA_interp = dir_working + r'\19. Plot SSA Extrapolation'
#     dir_fig_SAS_hi_Q = dir_working + r'\20. Plot SAS Data at High-Q'
#     dir_fig_SAS_comparison = dir_working + r'\21. Plot SAS Data Comparison'
#     dir_fig_fractal = dir_working + r'\22. Plot Fractal Fit'
#     dir_fig_Guinier = dir_working + r'\23. Plot Guinier Analysis'
#     dir_fig_Gn_combined = dir_fig_Guinier + r'\Combined Guinier Plot'
#     dir_fig_unified = dir_working + r'\24. Plot Unified Model'
#     dir_fig_unified_fit = dir_fig_unified + r'\01. Fitted Model'
#     dir_fig_unified_err = dir_fig_unified + r'\02. Model Error'
#     dir_fig_combined = dir_working + r'\25. Plot Combined Results'
    
    
#     dir_anisotropy_ratio = dir_working + r'\za. Anisotropy Ratio'
#     dir_ar_fig = dir_anisotropy_ratio + r'\Plots'
#     dir_ar_data = dir_anisotropy_ratio + r'\Data'
    
#     dir_ar_w_bkgrd = dir_working + r'\zb. Anisotropy Ratio with Background'
#     dir_ar_w_bkgrd_fig = dir_ar_w_bkgrd + r'\Plots'
#     dir_ar_w_bkgrd_data = dir_ar_w_bkgrd + r'\Data'
    
#     dir_ar_comparison = dir_working + r'\zc. Anisotropy Ratio Comparison'
    
#     dir_fit_annulus = dir_working + r'\zd. Fit Annulus Plot'
#     dir_fit_annulus_data = dir_fit_annulus + r'\1. Source Data'
#     dir_fit_annulus_result = dir_fit_annulus + r'\2. Fitted Data'
#     dir_fit_annulus_plot = dir_fit_annulus + r'\3. Annulus Plot'
#     dir_fit_annulus_plot_combined = dir_fit_annulus_plot + r'\zz. Combined Plot'



# def subtract_background_flat(QQ_original, IQ_original, QQ_max, 
#                              dI_original = [], bkgrd = None):
    
#     if bkgrd is None:
#         last_10 = IQ_original[-10:]
#         avg_last_10 = np.average(last_10)
#         std_last_10 = np.std(last_10)
#         sort_idx = np.argsort(last_10)
        
#         for i in sort_idx:
#             if last_10[i] >= avg_last_10 - 2*std_last_10:
#                 bkgrd = last_10[i]
#                 break
        
#     IQ_no_bkgrd = IQ_original-bkgrd
#     idx_IQ_negative = np.where(IQ_no_bkgrd <= 0)
    
#     try:
#         QQ_no_bkgrd = QQ_original[:np.min(idx_IQ_negative)]
#         IQ_no_bkgrd = IQ_no_bkgrd[:np.min(idx_IQ_negative)]
#         dI_no_bkgrd = dI_original[:np.min(idx_IQ_negative)] \
#             if dI_original is not None else dI_original
#     except ValueError:
#         QQ_no_bkgrd = QQ_original
#         IQ_no_bkgrd = IQ_no_bkgrd
#         dI_no_bkgrd = dI_original
    
#     remove_pos = QQ_no_bkgrd > QQ_max
#     QQ_4_analysis = QQ_no_bkgrd[~remove_pos]
#     IQ_4_analysis = IQ_no_bkgrd[~remove_pos]
#     dIQ_4_analysis = dI_no_bkgrd[~remove_pos] \
#         if dI_original != [] else dI_original

#     return QQ_4_analysis, IQ_4_analysis, dIQ_4_analysis, bkgrd   


# def subtract_background_not_flat(data, bkgrds):

#     data = data[data[:,0].argsort()]    

#     for curr_bkgrd in bkgrds:
#         if curr_bkgrd[0] == 'Fractal':
#             data[:,1] -= data[:,0]**curr_bkgrd[1][0] * 10**curr_bkgrd[1][1]
#         elif curr_bkgrd[0] == 'Guinier':
#             data[:,1] -= np.exp(curr_bkgrd[1][0]*data[:,0]**2 + curr_bkgrd[1][1])
        
#     if np.min(data) < 0:
#         less_than_0_pos = np.where(data[:,1] < 0)[0]
#         less_than_0_pos = np.insert(less_than_0_pos, 0, -1)
#         less_than_0_pos = np.append(less_than_0_pos, len(data)-1)
#         pos_dis = np.diff(less_than_0_pos)
#         pos_dis_max_pos = np.argmax(pos_dis)
#         start_point = less_than_0_pos[pos_dis_max_pos] + 1
#         end_point = less_than_0_pos[pos_dis_max_pos + 1]
#         data = data[start_point:end_point, :]
    
#     return data


# def find_longest_seg(pos_idx_list):
#     increment = np.diff(pos_idx_list)
#     pos_incr_not_1 = np.where(increment > 1)[0] + 1
#     segment_separator = np.concatenate(([0], pos_incr_not_1, [len(pos_idx_list)]))
#     segment_len = np.diff(segment_separator)
#     longest_seg_pos = np.where(segment_len == np.max(segment_len))[0][0]
#     longest_seg = pos_idx_list[list(range(segment_separator[longest_seg_pos], 
#                                           segment_separator[longest_seg_pos+1]))]
#     return longest_seg
    
# # find_longest_seg(np.array([2, 3, 4, 5, 12, 13, 14, 15, 16, 17, 20]))


def save_plot(fig, file_name, file_path):
    if not file_path.exists():
        file_path.mkdir()

    file_name = file_name.replace('.txt', '')
        
    fig.savefig(file_path / (file_name + '.svg'), bbox_inches='tight',
                dpi = 600)
    fig.savefig(file_path / (file_name + '.png'), bbox_inches='tight')


# def save_data(data, header, file_name, save_path):
#     if not os.path.exists(save_path):
#         os.makedirs(save_path)
    
#     file_name = file_name.replace('.txt', '').replace('.ABS', '')
        
#     with open(save_path + '\\' + 
#               file_name + '.txt', 'w', encoding='ascii') as file:
#         [file.write(line) for line in header]
#         [file.write('\t'.join(val if isinstance(val, str)
#                               else '{:.4e}'.format(val) 
#                               if val > 0 
#                               else '{:.3e}'.format(val) 
#                               for val in line) + '\n')
#                      for line in data]
           

# # Least square lineare fit for a set of data
# def linear_fit(x,y):
#     num_pts = len(x)
#     if num_pts <= 2:
#         raise ValueError('Need at least 3 points for fitting')
        
#     eqn,cov = np.polyfit(x, y, deg = 1, cov = True)
#     err = np.sqrt(np.diag(cov))

#     return eqn, err

# # eqn, err = linear_fit(np.array([150,175,200,225,250,275,300,325,350,375]), np.array([18,24,26,23,30,27,34,35,33,40]))
# # eqn, err = linear_fit(np.array([152,170,190,200,225,260,299,322,348,374]), np.array([18,24,26,23,30,27,34,35,33,40]))
# # print(eqn, err)

# def erf(x):
#     try:
#         return math.erf(x)
#     except:
#         return np.array([math.erf(val) for val in x])


# def make_ribbon_data(x_val, y_val, error = 0, num_pts = 200):
    
    
#     smooth_func = itp.make_interp_spline(x_val, y_val)
#     smooth_upper_func = itp.make_interp_spline(x_val, y_val +  error)
#     smooth_lower_func = itp.make_interp_spline(x_val, y_val -  error)
    
#     x_smooth = np.linspace(np.min(x_val), np.max(x_val), num_pts)
#     y_smooth = smooth_func(x_smooth)
#     y_upper_smooth = smooth_upper_func(x_smooth)
#     y_lower_smooth = smooth_lower_func(x_smooth)
        
#     return x_smooth, y_smooth, y_upper_smooth, y_lower_smooth
  

# def thin_SAS_data(QQ, IQ, dIQ = [], linspace_dis = 0.05, remove_neg = True):
    
#     thinned_data = []
    
#     sorted_idx = np.argsort(QQ)
#     QQ = QQ[sorted_idx]
#     IQ = IQ[sorted_idx]
#     dIQ = dIQ[sorted_idx] if list(dIQ) != [] else []
    
#     if remove_neg:
#         positive_IQ_pos = IQ > 0
#         QQ = QQ[positive_IQ_pos]
#         IQ = IQ[positive_IQ_pos]
#         dIQ = dIQ[positive_IQ_pos] if list(dIQ) != [] else []
    
#     log_Q_range = np.log10(QQ)
#     log_Q_min = np.min(log_Q_range)
#     log_Q_max = np.max(log_Q_range)
#     num_pts = int(np.ceil((log_Q_max-log_Q_min)/linspace_dis))
    
#     log_Q_ideal_range = np.linspace(log_Q_min, log_Q_max, num_pts)
#     prev_Q_pos = -1
#     prev_QQ_thinned = -1
    
#     for log_Q_ideal in log_Q_ideal_range:
#         log_Q_diff = np.abs(log_Q_ideal - log_Q_range)
#         Q_pos = np.where(log_Q_diff == min(log_Q_diff))[0][0]
        
#         if Q_pos != prev_Q_pos:
#             QQ_thinned = np.average(QQ[prev_Q_pos+1:Q_pos+1])
#             if abs(np.log10(QQ_thinned) - np.log10(prev_QQ_thinned)) < 0.5*linspace_dis:
#                 QQ_thinned = prev_QQ_thinned
#                 continue
#             IQ_thinned = np.average(IQ[prev_Q_pos+1:Q_pos+1])
#             if list(dIQ) != []:
#                 dIQ_thinned = (np.sqrt(np.sum(dIQ[prev_Q_pos+1:Q_pos+1]**2))/
#                                 len(dIQ[prev_Q_pos+1:Q_pos+1]))
#                 new_entry = np.column_stack((QQ_thinned, IQ_thinned, dIQ_thinned))
#             else:
#                 new_entry = np.column_stack((QQ_thinned, IQ_thinned))
#             thinned_data.append(new_entry)
#             prev_Q_pos = Q_pos
#             prev_QQ_thinned = QQ_thinned
    
#     thinned_data = np.row_stack(thinned_data)
#     QQ = thinned_data[:,0]
#     IQ = thinned_data[:,1]

#     if list(dIQ) == []:
#         return QQ, IQ
#     else:
#         dIQ = thinned_data[:,2]
#         return QQ, IQ, dIQ

# # Scattering length density of CD4 as a function of pressure
# def CD4_SLDvP():
    
#     N_A = 6.022e23           #1/mol
#     M_CD4 = 20.067           #g/mol
#     b_CD4 = 3.33e-4 * 10**-8 #cm
#     rho_CH4_CD4 =  1.25
    
#     SLD_v_pressure = {0: 0,
#                       50: 0.036977,
#                       100: 0.076454,
#                       150: 0.127208,
#                       200: 0.15824115,
#                       250: 0.199286,
#                       300: 0.213729,
#                       350: 0.242351,
#                       400: 0.249164,
#                       450: 0.263,
#                       500: 0.274148,
#                       600: 0.293294,
#                       700: 0.30165027,
#                       800: 0.31540918,
#                       900: 0.32916809,
#                       1000: 0.342927}
    
#     for pressure in SLD_v_pressure:
#         SLD_v_pressure[pressure] *= N_A/M_CD4*b_CD4*rho_CH4_CD4  #cm^-2
        
#     return SLD_v_pressure


# def make_sample_prop_table():
#     with open('aa_sample_prop_SANS.txt') as file:
#         data = np.array([line.replace('\t','').split(',') for line in file.readlines()[1:]],
#                         dtype = object)
                        
    
#     sample_name = data[:,0]
#     full_name = data[:, 1]
#     SLD_val = np.array(data[:,2], dtype = float)
#     dens_val = np.array(data[:,3], dtype = float)
    
#     name_table = dict(zip(sample_name, full_name))
#     SLD_table = dict(zip(sample_name, SLD_val))
#     dens_table = dict(zip(sample_name, dens_val))
    
#     return name_table, SLD_table, dens_table

# name_table, SLD_table, dens_table = make_sample_prop_table()

# def get_sample_prop(file_name):
#     file_name = file_name.lower()
#     if 'mar' in file_name:
#         key = 'Marcellus-measured'
#     elif 'paper' in file_name:
#         key = 'Paper'
#     elif 'pc' in file_name:
#         key = 'Pike County'
#     elif 'hc' in file_name:
#         key = 'Harrison County'
#     elif 'g060' in file_name:
#         key = 'G060'
#     elif 'g076' in file_name:
#         key = 'G076'
#     elif 'f183' in file_name:
#         key = 'F183'
#     elif 'il2' in file_name:
#         key = 'Illinois 2'
#     elif 'il3' in file_name:
#         key = 'Illinois 3'
#     elif 'gc' in file_name:
#         key = 'Gibson Core'
#     elif 'silica_aerogel' in file_name:
#         key = 'Silica Aerogel'
#     elif 'carbon_aerogel' in file_name:
#         key = 'Carbon Aerogel'
#     elif 'graphene' in file_name:
#         key = 'Graphene Aerogel'
#     elif '01h' in file_name:
#         key = '01H'
#     elif '01v' in file_name:
#         key = '01V'
#     elif '05h' in file_name:
#         key = '05H'
#     elif '05v' in file_name:
#         key = '05V'
#     elif '06h' in file_name:
#         key = '06H'
#     elif '06v' in file_name:
#         key = '06V'
#     elif '07h' in file_name:
#         key = '07H'
#     elif '07v' in file_name:
#         key = '07V'
#     elif '13h' in file_name:
#         key = '13H'
#     elif '13v' in file_name:
#         key = '13V'
#     elif '14h' in file_name:
#         key = '14H'
#     elif '14v' in file_name:
#         key = '14V'
#     elif 'alu' in file_name:
#         key = 'Alu'

#     sample_name = name_table[key]
#     SLD_val = SLD_table[key]
#     dens_val = dens_table[key]
    
#     sample_name += (' T-A' if '-a' in file_name else 
#                     ' T-B' if '-b' in file_name else '')
    
#     cond = []
#     try:
#         p_CD4 = [seg.replace('cd4','') for 
#                  seg in file_name.replace('.txt', '').replace('.dat','').split('_') 
#                  if 'cd4' in seg][0]
#         p_CD4 = 'p = ' + p_CD4 + ' bar'
#         p_CD4 += ' FINAL' if 'des' in file_name and 'h2o' not in file_name else ''
#         cond.append(p_CD4)
#     except:
#         pass
    
#     try:
#         p_H2O = [seg.replace('h2o','') for 
#                  seg in file_name.replace('.txt', '').split('_') 
#                  if 'h2o' in seg][0]
#         p_H2O = 'S = ' + p_H2O + ' bar'
#         # p_H2O += ' FINAL' if 'des' in file_name else ''
#         cond.append(p_H2O)
#     except:
#         pass
    
#     cond = ', '.join(cond)

    
#     return sample_name, cond, SLD_val, dens_val


# # Subtract the data set from the following equation
# def remove_background(data, bkgrd_type, *bkgrd_eqn):

#     data = data[data[:,0].argsort()]

#     if bkgrd_type == 'fractal':
#         for eqn in bkgrd_eqn:
#             data[:,1] -= data[:,0]**eqn[0] * 10**eqn[1]
    
#     elif bkgrd_type == 'Guinier':
#         for eqn in bkgrd_eqn:
#             data[:,1] -= eqn[1]*np.exp(eqn[0]*data[:,0]**2)
        
#     if np.min(data) < 0:
#         less_than_0_pos = np.where(data[:,1] < 0)[0]
#         less_than_0_pos = np.insert(less_than_0_pos, 0, -1)
#         less_than_0_pos = np.append(less_than_0_pos, len(data)-1)
#         pos_dis = np.diff(less_than_0_pos)
#         pos_dis_max_pos = np.argmax(pos_dis)
#         start_point = less_than_0_pos[pos_dis_max_pos] + 1
#         end_point = less_than_0_pos[pos_dis_max_pos + 1]
#         data = data[start_point:end_point, :]
    
#     return data


class FrozenClass(object):
    __isfrozen = False
    def __setattr__(self, key, value):
        if self.__isfrozen and not hasattr(self, key):
            raise TypeError( "Class {} is frozen. Cannot set {} = {}"
                            .format(type(self).__name__, key, value))
        object.__setattr__(self, key, value)

    def _freeze(self):
        self.__isfrozen = True
    pass


# # Least square lineare fit for a set of data
# def linear_fit(x,y):
#     n = len(x)
#     if n <= 2:
#         raise ValueError('Need at least 3 points for fitting')
        
#     x_bar = np.average(x)
#     y_bar = np.average(y)
    
#     sum_x = np.sum(x)
#     sum_y = np.sum(y)
#     sum_xy = np.sum(x*y)
#     sum_x2 = np.sum(x**2)
    
#     SS_xy = sum_xy - (sum_x*sum_y)/n
#     SS_x= sum_x2 - sum_x**2/n
    
#     # Find the slope and the y-interception
#     m = SS_xy/SS_x
#     b = y_bar - m*x_bar
#     eqn = np.array([m, b])

#     residues = y - (m*x + b)
#     err = np.sqrt(np.sum(residues**2)/(n-2))
    
#     return eqn, err 
