 # -*- coding: utf-8 -*-
"""
Created on Thu Jan  9 18:23:43 2020

@author: NHUHA
"""

import numpy as np
import pathlib as pl
import scipy.optimize as sci_opt

import zz_supported_functions as sp
import zz_plot_formating as pf

import matplotlib
matplotlib.use('Qt5Agg')


# Class representing unanalysed SANS data
class raw_SAS_data(sp.FrozenClass):
    
    def __init__(self):
        
        self.file_name = []
        self.instr_config = []
        self.original_file_name = []
        self.Q_range = []
        self.align_factor = []
        self.data = []
        
        self._freeze()


class join_SAS_data(sp.FrozenClass):
    
    def __init__(self):
        
        # Setting up directory
        dir_parent = pl.Path().resolve().parent
        self.dir_result = dir_parent / '03. Analysed Result'
        self.dir_raw_data_organised = self.dir_result / '01. Data Unanalysed'
        self.dir_combined_data = self.dir_result / '02. Data Joined'
        self.dir_fig_combined_data = self.dir_result / 'aa. Figures Combined Data'
        self.dir_fig_aligned_data = self.dir_result / 'bb. Figures Aligned Data'

        self.num_SAS_seg = 5 # Total number of scattering segments
        
        # Q ranges for USANS, SANS-lens, SANS-20m, SANS-8m, SANS-1.34m
        self.default_Q_range = [[0, 2e-3], 
                                [9e-4, 5.4e-3], [3e-3, 2.1e-2], 
                                [1e-2, 8e-2], [5e-2, 5.05e-1]][::-1]
        self.base_config = 'SANS-20' # SANS configuration to align data to
        self.Q_range_4_USANS_alignment = [2e-4, 1.5e-3] # Q range for fitting linear model to align SANS and USANS

        self.sample_name = []
        self.sample_save_name = []
        self.SAS_seg_list = []
        self.thinned_data = []
        self.combined_data = []
        self.pH2O = []
        self.pCD4 = []
        self.destress = True
        self.pos_sample_name = (0,3)

        # Prevent new attributes from being added
        self._freeze()
        
    # Execute program
    def run_program(self):
        num_runs = int(len(list(self.dir_raw_data_organised.iterdir())) /
                        (self.num_SAS_seg))
        
        for i in range(num_runs):
            self.SAS_seg_list = []
            self.join_data(i)
        

    def join_data(self, choice_data = None):
        print('File num: ', choice_data + 1)
        
        self.get_raw_SAS_data(choice_data)
        self.set_Q_range_and_align()
        self.write_result_combined()
            
        # Plot and save the SANS plot after the realignment process
        fig, _ = self.plot_aligned_data(plot_trimmed = False, show_plot = False)
        fig_save_path  = self.create_save_path(self.dir_fig_aligned_data, '.png')
        fig.savefig(fig_save_path)
        

    # Read the data from 1. Data Unanalysed and store the result in raw_SAS_data
    # This function is called by join_SAS_data
    def get_raw_SAS_data(self, choice = None):
        
        # Obtain the list of file in the Data Unanalysed directory
        file_list = (np.array(list(self.dir_raw_data_organised.iterdir())).
                     reshape((-1, self.num_SAS_seg)))
        cond_list = []
        
        # Create a list of experimental conditions based on the file names in
        # Data Unanalysed
        if len(file_list) > 0:
            for file_name in file_list[:,0]:
                current_cond = []
                file_name_info = file_name.parts[-1].replace('.txt', '').split('_')
                
                # Assign hydrostatic pressure by finding the string 'H2O' within
                # the file name. Add destressed to the condition if the string
                # 'des' is detected from the file name
                if 'H2O' in file_name.parts[-1]:
                    current_cond.append([pH2O for pH2O in file_name_info
                                         if 'H2O' in pH2O][0].replace('H2O', '') + 'bar' 
                                        + (' destressed' 
                                           if 'des' in file_name_info else ''))
                else:
                    current_cond.append('')
                    
                # Assign CD4 pressure by finding the string 'CD4' within
                # the file name
                if 'CD4' in file_name.parts[-1]:
                    current_cond.append([pCD4 for pCD4 in file_name_info
                                         if 'CD4' in pCD4][0].replace('CD4', '') + 'bar')
                else:
                    current_cond.append('')
                                         
                cond_list.append(current_cond)
        else:
            raise Exception('No data files in raw data folder')
        
        # Check if the choice for file has already been made, if not, ask the 
        # user to choose the file
        if choice == None:
            print('\nLIST OF AVAILABLE CONDITIONS:\n')
            
            for i in range(len(cond_list)):
                print((str(i) if i >= 10 else '0' + str(i)) + ': ' +
                      (cond_list[i][0] if self.is_ambient == True else '') +
                      ('Hydraulic Pressure = ' + cond_list[i][1] + ', '
                       if 'H2O' in file_name  else '') +
                      ('CD4 Pressure = ' + cond_list[i][2] 
                       if 'CD4' in file_name else ''))
                
            chosen_file = input('PLEASE CHOOSE A SET OF DATA FILE (0-'
                                  + str(len(cond_list)-1) + '): ')
            chosen_file = 0 if chosen_file == '' else int(chosen_file)
        
        else: chosen_file = choice
        
        chosen_file_list = file_list[chosen_file, :]
        instr_config_list = []
        
        # After the choice has been made, assign the sample name and the
        # experimental conditon to name the result file in the future
        sample_info = chosen_file_list[0].parts[-1].replace('.txt','').split('_')
        self.sample_name = '_'.join(sample_info[self.pos_sample_name[0]:
                                                self.pos_sample_name[1]])
        if 'H2O' in file_name.parts[-1]:
            self.pH2O = [pH2O for pH2O in sample_info
                         if 'H2O' in pH2O][0].replace('H2O','')
        if 'CD4' in file_name.parts[-1]:
            self.pCD4 = [pCD4 for pCD4 in sample_info
                         if 'CD4' in pCD4][0].replace('CD4','')
        
        self.destress = True if 'des' in sample_info else False

        # Assign the file_name, SANS/USANS instrument config to class raw_SAS_data
        # After the data has been obtained from the unanalysed files and
        # appended into the 
        for file_name in chosen_file_list:
            segment_info = file_name.parts[-1].replace('.txt','').split('_')

            with open(file_name) as file:
                file_data = file.readlines()
            
            # Data obtainable from file name
            SAS_seg_data = raw_SAS_data()
            SAS_seg_data.file_name = file_name
            instr_config = [instr_config for instr_config in segment_info
                            if ('SANS' in instr_config or 
                                'USANS' in instr_config)][0]
            SAS_seg_data.instr_config = instr_config
            instr_config_list.append(instr_config)  # for sorting the SAS segment
                                                    # a correct order
            
            # Data obtainable from data header
            SAS_seg_data.original_file_name = file_data[1].strip('\n')
            SAS_seg_data.Q_range = np.array(file_data[3].split(), float)
            SAS_seg_data.align_factor = float(file_data[5])
            
            SAS_seg_data.data = np.array([cur_line.strip('\n').split() 
                                          for cur_line in file_data[7:]], float)
            
            # Append the current segment to the list of scattering segments
            self.SAS_seg_list.append(SAS_seg_data)
        

        # Sort each SANS segment in SAS_seg_list in the order of increasing 
        # detector distance, follows by the USANS segment
        instr_config_stripped = []
        
        # Get the sample-detector distance from the list of SANS config
        for instr_config in instr_config_list:
            if not 'USANS' in instr_config:
                instr_config = instr_config.replace('SANS-','').replace('m','')
                if instr_config == 'SANS':
                    instr_config = 1 # For the case of only one SANS file such as Bilby
                else:
                    try: instr_config = float(instr_config)
                    except: pass
            instr_config_stripped.append(instr_config)
        
        # Put v-SANS segment at the second last position
        try:
            lens_idx = instr_config_stripped.index('lens')
            instr_config_stripped[lens_idx] = 99
        except:
            pass

        # Put the USANS segment at the final position
        try:
            USANS_idx = instr_config_stripped.index('USANS')
            instr_config_stripped[USANS_idx] = 100
        except:
            pass
        
        # Sort the different scattering segment by the order of decreasing
        # Q-range
        sorted_config_idx = sorted(range(len(instr_config_stripped)), 
                                   key=instr_config_stripped.__getitem__)
        self.SAS_seg_list = [self.SAS_seg_list[idx] 
                             for idx in sorted_config_idx]
        
        self.sample_save_name = self.sample_name
        self.sample_save_name += '_' + self.pH2O + 'H2O'
        self.sample_save_name += '_' + self.pCD4 + 'CD4'

    
    def set_Q_range_and_align(self):
        if len(self.default_Q_range) != self.num_SAS_seg:
            raise Exception('Number of Q-range pairs in __init__ is different ', 
                            'from number of SANS segment')

        for i in range(len(self.SAS_seg_list)):
            self.SAS_seg_list[i].Q_range = np.array(self.default_Q_range[i])
        align_factor_init = np.ones(len(self.SAS_seg_list)-1)

        sci_opt.least_squares(self.align_data, 
                              align_factor_init, jac = '3-point',
                              bounds = (0.2, 5))
        
        for SAS_seg in self.SAS_seg_list:
            self.write_raw_data(SAS_seg)
        
            
    def fit_lin_func(self, SAS_align_factor):
        joined_SAS_data = []
        align_fac_idx = 0
        eqn_list = []
        residue_list = []
        
        for SAS_seg in self.SAS_seg_list:
            Q_range = SAS_seg.Q_range
            SAS_data = SAS_seg.data[:,:2]
            SAS_data = SAS_data[np.logical_and(SAS_data[:,0] >= Q_range[0],
                                               SAS_data[:,0] <= Q_range[1])]
            
            if self.base_config not in SAS_seg.instr_config:
                SAS_seg.align_factor = SAS_align_factor[align_fac_idx]
                SAS_data[:,1] *= SAS_align_factor[align_fac_idx]
                align_fac_idx += 1
            else:
                SAS_seg.align_factor = 1
               
            joined_SAS_data.append(SAS_data)
           
        joined_SAS_data = np.vstack(joined_SAS_data)
        joined_SAS_data = joined_SAS_data[np.argsort(joined_SAS_data[:,0])]

        for i in range(len(self.SAS_seg_list)-1):
            if 'USANS' in self.SAS_seg_list[i+1].instr_config:
                fit_range_min = self.Q_range_4_USANS_alignment[0]
                fit_range_max = self.Q_range_4_USANS_alignment[1]
            else:
                fit_range_min = self.SAS_seg_list[i].Q_range[0]
                fit_range_max = self.SAS_seg_list[i+1].Q_range[1]
            data_4_fit = joined_SAS_data[np.logical_and(fit_range_min <= joined_SAS_data[:,0],
                                                        joined_SAS_data[:,0] <= fit_range_max), :]
            eqn, residue = np.polyfit(np.log10(data_4_fit[:,0]), 
                                      np.log10(data_4_fit[:,1]), 1, 
                                      full=True)[:2]
            
            eqn_list.append(eqn)
            residue_list.append(residue)
        return eqn_list, residue_list
        

    def align_data(self, SAS_align_factor):        
        _, residue_list = self.fit_lin_func(SAS_align_factor)            
        sum_err_square = np.sum(residue_list)
        
        return sum_err_square
    

    def write_raw_data(self, SAS_seg_data):
        file_dir = self.dir_raw_data_organised / SAS_seg_data.file_name
        with open(file_dir, 'w') as file:
            file.write('Original file name:\n' + 
                       SAS_seg_data.original_file_name + '\n')
            file.write('Q_range:\n')
            file.write('\t'.join("{:.5e}".format(val) for val  
                                     in SAS_seg_data.Q_range) + '\n')
            file.write('Alignment factor:\n')
            file.write(str(SAS_seg_data.align_factor) + '\n')
            file.write('\n')
            
            [file.write('\t'.join(line.astype(str))+'\n') for line in SAS_seg_data.data]
    

    def plot_aligned_data(self, plot_trimmed = True, show_plot = True):
        
        fig, ax = pf.new_plot()
        marker_style = pf.get_marker_list_short()[:self.num_SAS_seg]
        
        for i in range(len(self.SAS_seg_list)):
            
            plot_label = self.SAS_seg_list[i].instr_config
            align_factor = self.SAS_seg_list[i].align_factor
            Q_val = self.SAS_seg_list[i].data[:,0]
            IQ_val = self.SAS_seg_list[i].data[:,1]*align_factor
            error_val = self.SAS_seg_list[i].data[:,2]*align_factor

            try:
                start_pos = np.max(np.where(Q_val < 
                                            self.SAS_seg_list[i].Q_range[0])) + 1
            except ValueError:
                start_pos = 0
                
            try:
                end_pos = np.min(np.where(Q_val > 
                                          self.SAS_seg_list[i].Q_range[1]))
            except ValueError:
                end_pos = len(Q_val)

            select_Q = Q_val[start_pos:end_pos]
            select_IQ = IQ_val[start_pos:end_pos]
            select_error = error_val[start_pos:end_pos]
            
            removed_Q = np.concatenate((Q_val[:start_pos], Q_val[end_pos:]))
            removed_IQ = np.concatenate((IQ_val[:start_pos], IQ_val[end_pos:]))
            removed_error = np.concatenate((error_val[:start_pos], 
                                            error_val[end_pos:]))
            
            ax.plot(select_Q, select_IQ, marker_style[i], 
                    label= plot_label, zorder = 3 * (len(self.SAS_seg_list)-i))
            
            ax.errorbar(select_Q, select_IQ, yerr=select_error,
                        marker = '', linestyle = '', ecolor = marker_style[i][1], 
                        elinewidth=pf.marker_scale*2, capsize=pf.scale*2,
                        zorder = (len(self.SAS_seg_list)-i))

            
            if plot_trimmed == True:
                ax.plot(removed_Q, removed_IQ, marker = marker_style[i][0], 
                        linestyle = '', markerfacecolor = 'w', 
                        markeredgecolor = marker_style[i][1],
                        zorder = 2 * (len(self.SAS_seg_list)-i))
                ax.errorbar(removed_Q, removed_IQ, yerr=removed_error,
                            marker = '', linestyle = '', ecolor = marker_style[i][1], 
                            elinewidth=pf.marker_scale*2, capsize=pf.scale*2,
                            zorder = (len(self.SAS_seg_list)-i))
            
        pf.set_SAS_plot(fig, ax, is_fractal = True, tight_legend=True)    

        if show_plot == True:
            pf.show_figure()
            
        return fig, ax
        

    def write_result_thinned(self):

        result_save_path = self.create_save_path(sp.dir_thinned) +'.txt'
        
        
        with open(result_save_path, 'w') as file:
            file.write('Combined Scattering Data\n')
            file.write(' + '.join([SAS_data.original_file_name 
                                   for SAS_data in self.SAS_seg_list]) + '\n')
            file.write('Q\t\t\tI(Q)\t\t\tdI(Q)\n')
            [file.write('\t'.join("{:.10e}".format(val) for val in line)+'\n') 
             for line in self.thinned_data]
            
    def write_result_combined(self):
        
        joined_SAS_data = []
        for SAS_data in self.SAS_seg_list:
            Q_val = SAS_data.data[:,0]
            try:
                start_pos = np.max(np.where(Q_val < 
                                            SAS_data.Q_range[0])) + 1
            except ValueError:
                start_pos = 0
                
            try:
                end_pos = np.min(np.where(Q_val > 
                                          SAS_data.Q_range[1]))
            except ValueError:
                end_pos = len(Q_val)
            
            align_factor = SAS_data.align_factor
            
            SAS_val = SAS_data.data[start_pos:end_pos,:3].copy()
            SAS_val[:,1:] *= align_factor
            
            joined_SAS_data.append(SAS_val)
            
        joined_SAS_data = np.concatenate(joined_SAS_data)
        self.combined_data = joined_SAS_data

        save_path = self.create_save_path(self.dir_combined_data, '.txt')
        with open(save_path, 'w') as file:
            file.write('Combined Scattering Data\n')
            file.write(' + '.join([SAS_data.original_file_name 
                                   for SAS_data in self.SAS_seg_list]) + '\n')
            file.write('Q\t\t\tI(Q)\t\t\tdI(Q)\n')
            [file.write('\t'.join("{:.10e}".format(val) for val in line)+'\n') 
             for line in self.combined_data]
        
    def create_save_path(self, folder_dir, file_extension):
        if not folder_dir.exists():
            folder_dir.mkdir()

        sample_save_name = [self.sample_name]
        if self.pH2O != []: sample_save_name.append(self.pH2O + 'H2O')
        if self.pCD4 != []: sample_save_name.append(self.pCD4 + 'CD4')
        if self.destress == True:
            sample_save_name.append('_des')
        return folder_dir / ('_'.join(sample_save_name) + file_extension)
        
        
def main():
        
    join_data = join_SAS_data() 
    join_data.run_program()
        
        
if __name__ == "__main__":
    main()
